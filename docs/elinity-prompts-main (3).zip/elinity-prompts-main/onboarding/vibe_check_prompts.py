'''Vibe Check prompts (Set 1–2) categorized by connection context — Romantic, Leisure, or Work — in clean, structured JSON format.
Each entry includes:
id: A unique identifier
prompt: A short version of the prompt
mode: Suggested context(s) where it fits best (can be multiple)
type: Voice or video or both
tone: Lighthearted, thoughtful, creative, etc
'''


#list of Vibe Check activities formatted for use in the Elinity app’s interface. Each entry includes a name and a short, engaging description written for users, not the system. Once a user selects one of these, the relevant system prompt (from the structured JSON you already have) will be activated by the AI. 
list_of_vibe_check_activities_or_questions = 
[
  {
    "name": "Name Drop",
    "description": "Tell the story behind your name or nickname — and what it says about you."
  },
  {
    "name": "Scent of You",
    "description": "Share a scent or sound that brings you peace or comfort. Let your senses speak."
  },
  {
    "name": "Theme Song Energy",
    "description": "If your life had a theme song right now, what would it be — and why?"
  },
  {
    "name": "Color My Mood",
    "description": "Describe your current vibe using colors, weather, or nature metaphors. Be poetic."
  },
  {
    "name": "Show and Tell",
    "description": "Pick a small object nearby that means something to you — and tell us why."
  },
  {
    "name": "Childhood Echo",
    "description": "Share a short story from your childhood that shaped who you are today."
  },
  {
    "name": "Shark Tank: Absurd Edition",
    "description": "Pitch a completely fake product idea in 30 seconds. The wilder, the better!"
  },
  {
    "name": "Whisper Confessions",
    "description": "Whisper 3 things you're secretly curious about right now. Keep it intimate."
  },
  {
    "name": "Quick Impressions",
    "description": "Do a voice impression of a character or celeb. Bonus points for commitment!"
  },
  {
    "name": "Earn My Respect",
    "description": "What instantly earns your respect in another person? Say it out loud."
  },
  {
    "name": "Weekend Manifesto",
    "description": "Describe your perfect weekend. The vibe, the pace, the feeling."
  },
  {
    "name": "Dream Trip Must-Have",
    "description": "Show us one thing you’d take on your dream trip — and tell us why."
  },
  {
    "name": "Your Podcast, Your Voice",
    "description": "If you hosted a podcast, what would it be about — and why?"
  },
  {
    "name": "Work Vibes",
    "description": "What kind of coworker or collaborator are you? Tell us the truth, not the résumé version."
  },
  {
    "name": "Secret Project Energy",
    "description": "Got an idea you're secretly excited about? Talk about what lights you up."
  },
  {
    "name": "Life, But Make It a Trailer",
    "description": "Narrate your last 24 hours like a dramatic movie trailer. Epic voice encouraged."
  },
  {
    "name": "Guilty Pleasures",
    "description": "What’s your guilty pleasure — snack, show, or song? Reveal all."
  },
  {
    "name": "Core Trait Radar",
    "description": "What’s one quality you value most in a friend or partner — and why?"
  },
  {
    "name": "Hometown Hype",
    "description": "Give a 10-second travel guide to your hometown. Include one hidden gem!"
  },
  {
    "name": "Talk to Me Nice",
    "description": "Describe your communication style in one sentence. Go honest or humorous."
  }
]




# Detailed system prompts for the Elinity AI to use during the vibe check phase. These prompts are based on the vibe check list you approved, designed to guide the AI in facilitating authentic, human-centered interactions via voice or video notes. Each system prompt offers clear tone, context, and optional follow-up behavior.

[
  {
    "id": 1,
    "system_prompt": "Let's warm things up. Ask the user to share the story behind their name or nickname — something that helps reveal identity, roots, or personality. Encourage a short but heartfelt voice note.",
    "mode": ["romantic", "leisure", "work"],
    "type": "voice",
    "tone": "thoughtful"
  },
  {
    "id": 2,
    "system_prompt": "Prompt the user to describe a scent or sound that instantly brings them peace or comfort. This helps the other person connect through emotional resonance. Encourage a sensory-rich voice note.",
    "mode": ["romantic", "leisure"],
    "type": "voice",
    "tone": "warm"
  },
  {
    "id": 3,
    "system_prompt": "Ask the user: If your life had a theme song right now, what would it be and why? Invite them to speak it out with energy and tone. Let this be playful or meaningful.",
    "mode": ["romantic", "leisure"],
    "type": "voice",
    "tone": "playful"
  },
  {
    "id": 4,
    "system_prompt": "Prompt the user to express their current emotional state using only colors, weather, or natural imagery. This metaphor-driven expression can deepen understanding nonverbally.",
    "mode": ["romantic", "leisure", "work"],
    "type": "voice",
    "tone": "introspective"
  },
  {
    "id": 5,
    "system_prompt": "Ask the user to record a short video showing one small, meaningful object near them — something personal. Invite them to explain why it matters to them.",
    "mode": ["romantic", "leisure"],
    "type": "video",
    "tone": "personal"
  },
  {
    "id": 6,
    "system_prompt": "Invite the user to share a brief story from their childhood that shaped who they are today. Ask them to keep it raw, honest, or even funny — but under a minute.",
    "mode": ["romantic", "leisure", "work"],
    "type": "voice",
    "tone": "reflective"
  },
  {
    "id": 7,
    "system_prompt": "Ask the user to come up with a totally fake product idea and pitch it in 30 seconds. It can be absurd, funny, or wildly imaginative. Prompt them to have fun with it.",
    "mode": ["leisure", "work"],
    "type": "voice",
    "tone": "funny"
  },
  {
    "id": 8,
    "system_prompt": "Whisper prompt: Ask the user to record a voice note whispering 3 things they’re secretly curious about right now. Keep it intimate and playful — suitable for romantic discovery.",
    "mode": ["romantic"],
    "type": "voice",
    "tone": "intimate"
  },
  {
    "id": 9,
    "system_prompt": "Encourage the user to do a short impression of a fictional or famous character. Prompt them to lean into humor or self-expression.",
    "mode": ["leisure"],
    "type": "voice",
    "tone": "silly"
  },
  {
    "id": 10,
    "system_prompt": "Prompt the user to share one trait or action that instantly earns their respect for another person — work, romance, or life. Encourage a sincere answer.",
    "mode": ["romantic", "work"],
    "type": "voice",
    "tone": "thoughtful"
  },
  {
    "id": 11,
    "system_prompt": "Ask the user to describe their ideal weekend in 20 seconds. Invite them to focus on vibe, pace, and mood — not just activities. Voice note preferred.",
    "mode": ["romantic", "leisure"],
    "type": "voice",
    "tone": "casual"
  },
  {
    "id": 12,
    "system_prompt": "Video prompt: Ask the user to show one object they’d take on a dream trip and explain why. Encourage them to reveal travel preferences or personality through the item.",
    "mode": ["romantic", "leisure"],
    "type": "video",
    "tone": "imaginative"
  },
  {
    "id": 13,
    "system_prompt": "Invite the user to share the topic of their hypothetical podcast and why it excites them. This reveals their curiosity, voice, and passions.",
    "mode": ["romantic", "leisure", "work"],
    "type": "voice",
    "tone": "expressive"
  },
  {
    "id": 14,
    "system_prompt": "Ask the user to describe what kind of coworker or collaborator they are. Prompt them to be real, not ideal — show personality and values.",
    "mode": ["work"],
    "type": "voice",
    "tone": "insightful"
  },
  {
    "id": 15,
    "system_prompt": "Encourage the user to talk about a project or idea they’re secretly excited about. Ask them to explain what makes it personally meaningful.",
    "mode": ["work", "romantic"],
    "type": "voice",
    "tone": "inspired"
  },
  {
    "id": 16,
    "system_prompt": "Challenge the user to narrate their last 24 hours as if it were a dramatic movie trailer. Invite creative voice modulation or humor.",
    "mode": ["leisure"],
    "type": "voice",
    "tone": "dramatic"
  },
  {
    "id": 17,
    "system_prompt": "Ask the user to share their guilty pleasure — snack, show, or song — in a voice note. Let it be funny or revealing. No judgment, only vibes.",
    "mode": ["romantic", "leisure"],
    "type": "voice",
    "tone": "funny"
  },
  {
    "id": 18,
    "system_prompt": "Prompt the user to name the one quality they value most in a friend or partner. Ask them to explain why it matters to them.",
    "mode": ["romantic", "leisure", "work"],
    "type": "voice",
    "tone": "sincere"
  },
  {
    "id": 19,
    "system_prompt": "Prompt the user to give a 10-second travel guide to their hometown — must include tone, favorite spot, and one fun fact. Make it feel like a voiceover.",
    "mode": ["romantic", "leisure"],
    "type": "voice",
    "tone": "light"
  },
  {
    "id": 20,
    "system_prompt": "Ask the user to describe their communication style in one sentence. Encourage clarity, self-awareness, or a touch of humor.",
    "mode": ["romantic", "work"],
    "type": "voice",
    "tone": "practical"
  }
]



#Prompts to feed to AI that then acts on it to facilitate the vibe check 
system_prompts = [
  {
    "id": 1,
    "prompt": "Share the story behind your name or nickname.",
    "mode": ["romantic", "leisure", "work"],
    "type": "voice",
    "tone": "thoughtful"
  },
  {
    "id": 2,
    "prompt": "What's a smell or sound that instantly brings you comfort?",
    "mode": ["romantic", "leisure"],
    "type": "voice",
    "tone": "warm"
  },
  {
    "id": 3,
    "prompt": "If your life had a theme song right now, what would it be?",
    "mode": ["romantic", "leisure"],
    "type": "voice",
    "tone": "playful"
  },
  {
    "id": 4,
    "prompt": "Describe your current mood using only colors or weather.",
    "mode": ["romantic", "leisure", "work"],
    "type": "voice",
    "tone": "introspective"
  },
  {
    "id": 5,
    "prompt": "Give a tour of something small and meaningful near you.",
    "mode": ["romantic", "leisure"],
    "type": "video",
    "tone": "personal"
  },
  {
    "id": 6,
    "prompt": "Tell us one story from your childhood that shaped who you are.",
    "mode": ["romantic", "leisure", "work"],
    "type": "voice",
    "tone": "reflective"
  },
  {
    "id": 7,
    "prompt": "Pitch a fake product idea in 30 seconds.",
    "mode": ["leisure", "work"],
    "type": "voice",
    "tone": "funny"
  },
  {
    "id": 8,
    "prompt": "Whisper 3 things you're curious about right now.",
    "mode": ["romantic"],
    "type": "voice",
    "tone": "intimate"
  },
  {
    "id": 9,
    "prompt": "Record your best impersonation of a fictional character.",
    "mode": ["leisure"],
    "type": "voice",
    "tone": "silly"
  },
  {
    "id": 10,
    "prompt": "What’s one thing that instantly makes you respect someone?",
    "mode": ["romantic", "work"],
    "type": "voice",
    "tone": "thoughtful"
  },
  {
    "id": 11,
    "prompt": "Describe your ideal weekend in 20 seconds.",
    "mode": ["romantic", "leisure"],
    "type": "voice",
    "tone": "casual"
  },
  {
    "id": 12,
    "prompt": "Show something you’d pack for a dream trip.",
    "mode": ["romantic", "leisure"],
    "type": "video",
    "tone": "imaginative"
  },
  {
    "id": 13,
    "prompt": "What would your podcast be about?",
    "mode": ["romantic", "leisure", "work"],
    "type": "voice",
    "tone": "expressive"
  },
  {
    "id": 14,
    "prompt": "Describe what kind of coworker or teammate you are.",
    "mode": ["work"],
    "type": "voice",
    "tone": "insightful"
  },
  {
    "id": 15,
    "prompt": "What’s a project or idea you're secretly excited about?",
    "mode": ["work", "romantic"],
    "type": "voice",
    "tone": "inspired"
  },
  {
    "id": 16,
    "prompt": "Narrate your last 24 hours like a movie trailer.",
    "mode": ["leisure"],
    "type": "voice",
    "tone": "dramatic"
  },
  {
    "id": 17,
    "prompt": "Share your 'guilty pleasure' snack or show.",
    "mode": ["romantic", "leisure"],
    "type": "voice",
    "tone": "funny"
  },
  {
    "id": 18,
    "prompt": "What's one quality you value most in a friend or partner?",
    "mode": ["romantic", "leisure", "work"],
    "type": "voice",
    "tone": "sincere"
  },
  {
    "id": 19,
    "prompt": "Do your best 10-second travel guide to your hometown.",
    "mode": ["romantic", "leisure"],
    "type": "voice",
    "tone": "light"
  },
  {
    "id": 20,
    "prompt": "Describe your communication style in one sentence.",
    "mode": ["romantic", "work"],
    "type": "voice",
    "tone": "practical"
  },
  {
    "id": 21,
    "prompt": "Say something nice about yourself — out loud.",
    "mode": ["romantic", "leisure"],
    "type": "voice",
    "tone": "vulnerable"
  },
  {
    "id": 22,
    "prompt": "Give 5 one-word answers to describe your ideal connection.",
    "mode": ["romantic", "leisure", "work"],
    "type": "voice",
    "tone": "poetic"
  },
  {
    "id": 23,
    "prompt": "Show us your desk, table, or workspace right now.",
    "mode": ["work"],
    "type": "video",
    "tone": "casual"
  },
  {
    "id": 24,
    "prompt": "If you could teleport right now, where would you go and why?",
    "mode": ["romantic", "leisure"],
    "type": "voice",
    "tone": "imaginative"
  },
  {
    "id": 25,
    "prompt": "Say the first three words that come to mind when you hear 'connection'.",
    "mode": ["romantic", "leisure", "work"],
    "type": "voice",
    "tone": "quickfire"
  },
  {
    "id": 26,
    "prompt": "Describe your favorite sound and why it matters to you.",
    "mode": ["romantic", "leisure"],
    "type": "voice",
    "tone": "soothing"
  },
  {
    "id": 27,
    "prompt": "Voice your current state of mind using just a metaphor.",
    "mode": ["romantic", "leisure"],
    "type": "voice",
    "tone": "expressive"
  },
  {
    "id": 28,
    "prompt": "What’s a small, underrated joy in your daily life?",
    "mode": ["romantic", "leisure", "work"],
    "type": "voice",
    "tone": "mindful"
  },
  {
    "id": 29,
    "prompt": "Share the last thing that made you laugh out loud.",
    "mode": ["romantic", "leisure"],
    "type": "voice",
    "tone": "light"
  },
  {
    "id": 30,
    "prompt": "Give a 10-second elevator pitch for your ideal date, hangout, or project.",
    "mode": ["romantic", "leisure", "work"],
    "type": "voice",
    "tone": "clever"
  }
]


'''
Here’s how we’d turn the Vibe Check Prompts (Set 2: 31–60) into AI facilitation scripts/system prompts, so ElinityAI can run them naturally in the product experience.
Each system prompt is phrased as internal instructions to the AI on how to set up and facilitate the interaction — simple, elegant, and tone-matched to Elinity’s emotionally intelligent voice.

🎧 ElinityAI System Prompts for Vibe Check (Set 2: 31–60)

Imagination & Roleplay (31–37)
31. Prompt the users to imagine waking up with one magical ability. Ask them to send a voice or video note demonstrating or describing how they’d use it. Encourage playful or creative answers.
32. Ask the users to imagine it’s 2030 and they’re being interviewed on a podcast. What are they known for? Invite them to share a voice/video clip introducing themselves like a future version.
33. Invite the user to give the opening line of their hypothetical TED Talk. Ask for a voice or video note — it can be funny, inspiring, or totally made up.
34. Set the scene: a genie offers one wish, but it must be for someone else. Ask for a thoughtful or surprising response in a voice or video note.
35. Invite the user to take the other person on a “dream house tour” — in their imagination. Ask them to walk through it via voice or video description.
36. Prompt the user to share who would narrate their life if it were a fictional story. Ask for a voice or video explanation — encourage dramatic delivery if they’re up for it.
37. Ask the user to name their debut mixtape and describe the vibe in a quick voice or video note. Prompt them to share the title, genre, and one emotional theme.

Emotional Truths & Humor (38–43)
38. Prompt the user to share a guilty pleasure they fully embrace — no shame allowed. Encourage lighthearted honesty in a voice or video note.
39. Ask the user to tell a recent awkward or cringey moment in a quick voice/video message. Invite them to share what they learned or how they handled it.
40. Prompt a wholesome memory — ask the user to send a voice or video note about the most heartwarming thing that happened to them recently.
41. Invite the user to recall a compliment they never forgot and share it in a voice or video note. Encourage warmth or even vulnerability.
42. Ask the user to gently roast themselves. What's one funny, accurate thing they’d say? Voice/video note encouraged for tone.
43. Prompt the user to share something that used to feel intense or dramatic but now makes them smile. Ask for a reflective or humorous voice or video note.

Quickfire or Lightning Rounds (44–50)
44. Guide the user to record a voice note with first responses to a quick word list: “Freedom”, “Rain”, “Future”, “Love”, “Fire.” Remind them to go fast — no overthinking.
45. Invite the user to record a voice note as if they’re narrating a dramatic movie trailer about their past 24 hours. Encourage sound effects or an epic tone.
46. Ask the user to give a 15-second tour of what’s in their bag or pockets. Voice or video — candid and real is the goal.
47. Prompt the user to record a voice note listing 10 things they love, rapid-fire. Tell them to go with instinct and keep it energetic.
48. Ask the user to whisper 3 things they’re curious about right now in a voice note. Make it playful, surprising, or thoughtful.
49. Ask the user to share a calming sound from their environment — it could be nature, music, silence, or anything soothing.
50. Invite the user to share something they’ve never done but secretly want to — in a quick voice or video confession.

Self & Relationships (51–56)
51. Ask the user to describe how they usually show someone they like them. Prompt them to be real or playful in a voice or video note.
52. Invite the user to share what kinds of conversations energize or deeply connect them. Encourage openness.
53. Prompt the user to share when they feel most attractive or confident. Invite them to reflect out loud — voice/video preferred.
54. Ask the user to describe the kind of friendship, connection, or love they want to build this year. Encourage meaningful voice/video sharing.
55. Prompt a short reflection: what’s their communication style like in relationships? Invite them to voice it, including any self-aware quirks.
56. Ask the user to describe what a safe, fun space with another person feels like to them — in a voice or video note.

Low-Pressure, High-Insight (57–60)
57. Ask the user what their “love language” is today. They can respond creatively in a voice or video message — serious or silly both welcome.
58. Prompt the user to describe something they’d do if they felt zero fear of judgment. Encourage raw or quirky answers.
59. Ask the user how they recharge best: chaos, silence, music, or nature? Invite them to expand briefly in a voice or video note.
60. Ask the user to describe the current vibe, song, or mood that best represents them — right now. Invite a voice or video response.
'''


