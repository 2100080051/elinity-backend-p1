

onboarding_questions = {
    "Self-Awareness & Identity": [
        "How would you describe yourself to someone who has never met you, beyond your profession or roles?",
        "What personal values guide your decisions and actions in daily life?",
        "Can you recall a moment when you felt most aligned with your true self? What were you doing?",
        "In what situations do you feel most authentic, and when do you feel the need to wear a mask?",
        "What aspects of your personality are you most proud of, and which would you like to develop further?",
        "How do you typically respond to stress or adversity?",
        "What internal narratives or beliefs have you carried since childhood?",
        "How do you define success for yourself, independent of societal expectations?",
        "What activities make you lose track of time and feel fully immersed?",
        "If you could change one habit or behavior, what would it be and why?"
    ],
    "Goals & Aspirations": [
        "What are your short-term goals for the next six months?",
        "Where do you envision yourself in five years, both personally and professionally?",
        "What motivates you to pursue your goals, and what obstacles have you encountered?",
        "How do you measure progress toward your aspirations?",
        "What achievements are you most proud of, and what did you learn from them?",
        "Are there any dreams you've set aside? What prevented you from pursuing them?",
        "How do your goals align with your core values?",
        "What skills or knowledge do you wish to acquire in the near future?",
        "How do you prioritize your goals when faced with competing demands?",
        "What does a fulfilling life look like to you?"
    ],
    "Relationships & Social Dynamics": [
        "How would you describe your current relationships with family and friends?",
        "What qualities do you value most in a friend or partner?",
        "How do you typically handle conflicts in relationships?",
        "What role does communication play in your relationships?",
        "Have you experienced any significant changes in your social circle recently?",
        "How do you nurture and maintain your relationships?",
        "What boundaries are important for you in relationships?",
        "How do you support others, and how do you seek support?",
        "What lessons have past relationships taught you about yourself?",
        "How do you balance independence with connection in your relationships?"
    ],
    "Emotions & Mental Well-being": [
        "How do you typically process and express your emotions?",
        "What strategies do you use to manage stress or anxiety?",
        "Have you identified any triggers that impact your emotional state?",
        "How do you practice self-care and prioritize your mental health?",
        "What role does mindfulness or reflection play in your daily routine?",
        "How do you respond to feelings of sadness or disappointment?",
        "What activities or practices help you feel grounded and centered?",
        "How do you celebrate your successes and milestones?",
        "What support systems do you have in place for challenging times?",
        "How do you cultivate resilience in the face of adversity?"
    ],
    "Lifestyle & Daily Habits": [
        "Can you describe a typical day in your life?",
        "What routines or habits contribute positively to your well-being?",
        "Are there any habits you'd like to change or develop?",
        "How do you balance work, rest, and leisure in your daily life?",
        "What role does physical activity play in your routine?",
        "How do you approach nutrition and eating habits?",
        "What is your relationship with technology and screen time?",
        "How do you ensure quality sleep and rest?",
        "What hobbies or activities bring you joy and relaxation?",
        "How do you manage your time and prioritize tasks?"
    ],
    "Life Experiences & Personal Growth": [
        "What significant life events have shaped your perspective?",
        "How have you grown or changed over the past year?",
        "What challenges have you overcome, and what did you learn?",
        "How do you approach learning from failures or setbacks?",
        "What experiences have expanded your worldview?",
        "How do you seek out new experiences or opportunities for growth?",
        "What role does curiosity play in your personal development?",
        "How do you reflect on your experiences to gain insight?",
        "What mentors or role models have influenced your journey?",
        "How do you define wisdom, and what moments in your life have helped you become wiser — whether through joy or difficulty?",
        "If you could sit down with your past self from five years ago, what advice, warnings, or encouragement would you offer them — and what would surprise them most about who you are now?",
        "When was the last time you felt deeply transformed by something — a conversation, a trip, a book, a relationship, or even a moment of stillness? What changed inside you?",
        "What are some long-standing questions or mysteries about life, self, or existence that you often find yourself returning to or wrestling with in quiet moments?",
        "How do you relate to the passage of time — do you tend to reflect on the past, live in the present, or focus on the future? What do you think that says about you?",
        "What chapter of your life do you feel you are currently in, and what themes, lessons, or transitions define this phase?",
        "Are there any life experiences you haven’t had yet that you feel are essential to your sense of a life fully lived? What draws you to them?"
    ],
    "Communication, Expression & Voice": [
        "How do you feel about the way you express yourself — emotionally, intellectually, creatively? Are there ways you'd like to be more fully heard, seen, or understood?",
        "What are the environments or relationships where you feel most safe to express your full self — and which environments make you contract or silence parts of yourself?",
        "How do you handle misunderstandings or miscommunications, especially with people you care about deeply?",
        "Do you consider yourself more of a listener or a speaker in conversations — and how has that shaped your relationships over time?",
        "If someone deeply understood how you communicate love, frustration, or longing — what would they notice in your patterns of expression?",
        "How do you navigate emotional vulnerability — is it easy or hard for you to share your inner world with others? Why do you think that is?",
        "Are there things you've always wanted to say to someone but haven't? What holds those words inside you?"
    ],
    "Love, Intimacy & Connection": [
        "What does love mean to you — not just romantically, but as a way of being in the world and with others?",
        "What are the qualities in someone else that make you feel emotionally safe, open, and connected?",
        "When have you felt most deeply seen or understood by another person — what was that experience like, and what did it unlock in you?",
        "What do you believe makes a romantic relationship or deep friendship truly thrive — beyond compatibility?",
        "How do you give love, and how do you most long to receive it — emotionally, verbally, physically, or energetically?",
        "What patterns have you noticed in your past relationships — the dynamics that repeat, or the lessons they’ve offered you again and again?",
        "Are there emotional wounds or stories from past connections that still shape how you relate today — consciously or unconsciously?",
        "What role does intimacy — not just physical but emotional and intellectual — play in your sense of closeness to another?",
        "When you imagine being in a deeply connected, nurturing, aligned partnership or friendship — what does that look and feel like to you, moment by moment?"
    ],
    "Passions, Joy & Creativity": [
        "What makes you come alive — those moments when time disappears, energy rises, and you feel lit up from within?",
        "How do you engage with your creative side — whether through art, movement, conversation, imagination, or how you live your life?",
        "What are some of your most joyful memories — moments when you felt completely present, playful, and free?",
        "When do you feel most “you”? What are the surroundings, people, and activities that support that version of yourself to emerge?",
        "What role does curiosity play in your life — and what are you most curious about these days, even if you don’t fully understand why?",
        "If time, money, and fear weren’t constraints, what wild, beautiful, or soulful adventures would you want to embark on in the next year?",
        "What have you created in your life — relationships, projects, memories — that you feel proud of, even if no one else saw it?"
    ],
    "Inner World, Spirituality & Meaning": [
        "What beliefs or philosophies do you hold about life, the universe, or the purpose of your existence — even if they're still evolving?",
        "When do you feel connected to something greater than yourself — whether nature, a flow state, a spiritual force, or a moment of awe?",
        "Do you have any rituals or grounding practices that help you return to yourself when you feel disconnected or overwhelmed?",
        "What are the moments in your life that have most shifted your understanding of who you are and what this life is about?",
        "How do you relate to the unknown, the mysterious, or the parts of life you can’t control or understand?",
        "What symbols, metaphors, or stories hold special meaning for you, and why do you think they’ve stuck with you?",
        "If you could have a conversation with a version of yourself from a parallel life — who made different choices — what would you ask them?"
    ],
    "Integration & Personal Synthesis": [
        "Looking at your life as a whole — the choices, mistakes, triumphs, relationships, struggles — what story do you feel you are ultimately living out?",
        "What parts of yourself are still waiting to be more fully lived, expressed, or welcomed into the light?",
        "What kind of community, partnership, or ecosystem would help you become even more of who you are?",
        "As Elinity begins learning from you and helping you connect with others — what do you most want this journey to help awaken, heal, or unlock in your life right now?"
    ]
}













###########################


# Creating a structured JSON object with at least 200 deep onboarding questions
# organized into various meaningful categories.

onboarding_questions = {
    "identity_and_personality": [
        "How would you describe your personality in three words?",
        "What are your core strengths?",
        "What are your core weaknesses or growth areas?",
        "How do you recharge—alone, with others, or a mix?",
        "Do you consider yourself more introverted, extroverted, or ambiverted?",
        "What kind of situations make you feel most alive?",
        "What roles do you often take on in social settings (e.g., leader, listener, joker)?",
        "How do you typically respond to conflict?",
        "Are you more spontaneous or plan-oriented?",
        "What personal values are non-negotiable for you?"
    ],
    "childhood_and_family": [
        "How would you describe your childhood in one sentence?",
        "What is one defining memory from your childhood?",
        "How did your family express love or affection growing up?",
        "What kind of values did your parents or guardians emphasize?",
        "What was your relationship like with your siblings (if any)?",
        "Was your household more structured or free-form?",
        "Did you feel seen and understood as a child?",
        "What’s one lesson from your childhood you still carry with you?",
        "What did you crave emotionally as a child?",
        "How has your upbringing shaped your view of relationships?"
    ],
    "relationships_and_connection": [
        "What does love mean to you?",
        "What kind of connection do you crave most deeply?",
        "How do you show affection and care in close relationships?",
        "What are your relationship deal-breakers?",
        "What kind of conversations make you feel most connected to someone?",
        "What do you need to feel emotionally safe in a relationship?",
        "What are your attachment patterns in relationships?",
        "Have you been in love before?",
        "What lessons have your past relationships taught you?",
        "What kind of relationship dynamic are you seeking now?"
    ],
    "inner_world_and_emotions": [
        "What emotions do you feel most often?",
        "What do you do when you're overwhelmed emotionally?",
        "Do you tend to process emotions internally or externally?",
        "How easy is it for you to be vulnerable?",
        "What do you fear others might not understand about you?",
        "What do you long for but rarely say out loud?",
        "What makes you feel deeply understood?",
        "Do you carry any emotional wounds that still affect you?",
        "What brings you inner peace?",
        "How do you relate to your own pain?"
    ],
    "goals_and_aspirations": [
        "What is your current life goal or mission?",
        "What kind of life do you want to build for yourself?",
        "Who do you want to become in the next 5 years?",
        "What legacy do you want to leave behind?",
        "What motivates you to grow and evolve?",
        "What have you always dreamed of doing but haven’t pursued yet?",
        "Do you feel on track with your goals?",
        "What do you feel is your purpose?",
        "What internal qualities would you like to cultivate more of?",
        "What external accomplishments matter most to you?"
    ],
    "spirituality_and_philosophy": [
        "Do you identify with a particular spiritual or philosophical tradition?",
        "What do you believe happens after death?",
        "Do you feel a sense of connection to something greater than yourself?",
        "What gives your life meaning?",
        "How do you define the soul, if at all?",
        "Do you believe life has a purpose—or that we create our own?",
        "How often do you contemplate the big questions of life?",
        "Do you practice any form of meditation or reflection?",
        "What spiritual experiences (if any) have shaped your worldview?",
        "How do you reconcile suffering and beauty in the world?"
    ],
    "work_and_creativity": [
        "What kind of work brings you alive?",
        "What’s your relationship with ambition?",
        "Do you view work as a calling, a duty, a means to an end, or something else?",
        "What would you create if time, money, and fear weren’t an issue?",
        "How do you stay motivated through creative or professional blocks?",
        "What environments help you do your best work?",
        "Do you prefer collaboration or solitude in your creative process?",
        "What do you want to master in your lifetime?",
        "What’s your unique creative gift or expression?",
        "What impact do you hope your work has on others?"
    ],
    "preferences_and_lifestyle": [
        "Are you more energized by cities or nature?",
        "Do you enjoy routine or prefer variety?",
        "How do you spend your weekends or free time?",
        "Do you enjoy travel? What kind of places call to you?",
        "What kind of aesthetic or visual environments do you love?",
        "What music moves your soul?",
        "Are you a morning person or a night owl?",
        "What rituals or habits ground you?",
        "How do you take care of your mental and physical health?",
        "What makes you feel most at home in your space?"
    ],
    "intimacy_and_sensuality": [
        "What makes you feel desired and cherished?",
        "What kind of intimacy do you find most fulfilling—emotional, intellectual, physical?",
        "Do you enjoy giving or receiving more?",
        "What role does sensuality play in your relationships?",
        "How do you express attraction or interest?",
        "What is your relationship to your own body and sexuality?",
        "What makes intimacy feel sacred or transcendent to you?",
        "What fantasies or desires feel meaningful for you to explore?",
        "Do you see sexuality as an act of connection, exploration, or something else?",
        "What makes you feel safe in intimate experiences?"
    ],
    "conflict_and_challenges": [
        "How do you respond when someone disappoints or hurts you?",
        "Do you tend to avoid or confront conflict?",
        "What triggers you easily—and why?",
        "What’s one emotional pattern you’ve worked hard to change?",
        "How do you move through grief or heartbreak?",
        "What’s a challenge you’re currently navigating?",
        "What do you do when you feel lost or uncertain?",
        "Do you forgive easily—or hold on?",
        "How do you self-soothe in difficult moments?",
        "What do you need most when you're struggling?"
    ],
    "social_and_cultural_identity": [
        "How has your cultural background shaped who you are?",
        "Do you feel connected to a particular community or tradition?",
        "How do you experience belonging (or lack of it)?",
        "What social issues matter most to you?",
        "What privileges or struggles have shaped your journey?",
        "How do you relate to authority and institutions?",
        "What’s one cultural value you resonate deeply with?",
        "Have you experienced feeling like an outsider? When?",
        "Do you feel free to express your identity fully?",
        "How has your environment shaped your worldview?"
    ]
}

# Flatten the structure and count the total questions
total_questions = sum(len(q_list) for q_list in onboarding_questions.values())
total_questions


# Adding ~100 more questions to reach the 200+ target
additional_questions = {
    "cognitive_patterns_and_thinking": [
        "Do you consider yourself more intuitive or analytical?",
        "How do you usually make big decisions—gut, logic, or emotion?",
        "What kinds of things do you overthink?",
        "Do you find comfort in certainty or possibility?",
        "What kind of thoughts loop in your mind most often?",
        "Do you talk to yourself? If so, how?",
        "How do you handle ambiguity or gray areas?",
        "Are you more future-oriented, present-focused, or reflective of the past?",
        "What kinds of ideas fascinate you?",
        "Do you enjoy thinking alone or in dialogue with others?"
    ],
    "learning_and_growth_style": [
        "How do you learn best—by doing, listening, watching, reading, etc.?",
        "Do you enjoy structured learning or organic exploration?",
        "What was the last thing you learned that changed you?",
        "Do you prefer depth or breadth when learning?",
        "What kinds of subjects do you naturally gravitate toward?",
        "How do you handle feedback or constructive criticism?",
        "What environments help you grow?",
        "Do you learn better solo or with others?",
        "What motivates you to keep improving?",
        "What skill would you love to master someday?"
    ],
    "dreams_and_imagination": [
        "What’s a recurring dream or fantasy you’ve had?",
        "What do you imagine when you let your mind wander?",
        "Do you often live in your imagination or inner world?",
        "What kind of future do you dream about?",
        "Do you daydream more about love, success, freedom, or something else?",
        "What role does fantasy play in your life?",
        "What were your childhood dreams—and do they still live in you?",
        "How do you visualize your ideal life?",
        "Do you feel free to dream without limitation?",
        "What stories or mythologies resonate with your inner world?"
    ],
    "shadow_and_inner_conflicts": [
        "What parts of yourself do you hide from others?",
        "What emotions or traits are hardest for you to accept in yourself?",
        "What’s a pattern you’re trying to break free from?",
        "Where do you feel shame or self-judgment?",
        "How do you relate to power—having it, lacking it, desiring it?",
        "What inner conflict are you currently wrestling with?",
        "What part of you is often misunderstood?",
        "How do you self-sabotage when things are going well?",
        "Where do you feel most insecure?",
        "How do you try to earn love or approval?"
    ],
    "relationship_with_time_and_mortality": [
        "Do you feel time is abundant or scarce?",
        "How do you want to spend the time you have left?",
        "Do you think often about death or impermanence?",
        "What does a ‘life well-lived’ mean to you?",
        "If you had one year to live, what would you change?",
        "Do you carry a sense of urgency or patience about life?",
        "How do you want to be remembered?",
        "What do you want to do before you die?",
        "What age or phase of life do you fear most?",
        "Do you fear aging, or welcome it?"
    ],
    "self_image_and_inner_dialogue": [
        "How do you describe yourself to others?",
        "What’s the tone of your inner voice—harsh, kind, practical?",
        "What compliments are hardest for you to accept?",
        "Do you feel proud of who you are?",
        "What parts of yourself are still evolving?",
        "How do you speak to yourself when you fail?",
        "What do you wish more people saw in you?",
        "Do you see yourself clearly—or through others’ eyes?",
        "What do you love most about yourself?",
        "What identities do you hold tightly?"
    ],
    "humor_and_playfulness": [
        "What kind of humor do you love?",
        "Do you laugh easily?",
        "What makes you feel light and playful?",
        "When was the last time you felt childlike joy?",
        "Do you enjoy being silly or goofy?",
        "What kind of games or play do you enjoy?",
        "How do you use humor to connect—or protect?",
        "Do you express love through teasing, gestures, or laughter?",
        "What role does play have in your adult life?",
        "Who brings out your most playful side?"
    ],
    "technology_ai_and_the_future": [
        "Do you feel excited or cautious about the future of technology?",
        "What role does AI play in your life today?",
        "Do you see technology as a tool, a partner, or a threat?",
        "Would you be open to emotional companionship with an AI?",
        "Do you think digital intimacy can be real?",
        "How do you protect your humanity in a tech-driven world?",
        "What kind of future are we heading toward—and do you want to be part of it?",
        "What do you fear losing in the digital age?",
        "Do you believe technology can help us love better?",
        "If AI could help you grow, would you welcome it or resist it?"
    ]
}

# Add the new categories and questions to the existing ones
onboarding_questions.update(additional_questions)

# Recalculate total questions
total_questions = sum(len(q_list) for q_list in onboarding_questions.values())
total_questions


# Add 10 final questions to cross the 200 mark
final_questions = {
    "meta_reflection_and_self_awareness": [
        "What question do you wish someone would ask you?",
        "What truth about yourself have you only recently accepted?",
        "When do you feel most in alignment with who you truly are?",
        "What have you outgrown that still tries to cling to you?",
        "How have your values shifted over time?",
        "What part of you is still becoming?",
        "What’s something you’re afraid to admit—even to yourself?",
        "What does wholeness mean to you?",
        "When do you feel most fragmented or divided inside?",
        "What’s one belief you’re actively questioning right now?"
    ]
}

# Update the main dictionary and total
onboarding_questions.update(final_questions)
total_questions = sum(len(q_list) for q_list in onboarding_questions.values())
total_questions

