
# list of the icebreaker games and activities previously generated, now tagged by context (general, romantic, leisure, collaboration) and other relevant metadata such as number of players, play mode, and AI role.

icebreaker_activities = [
    {
        "name": "Two Truths and a Lie",
        "description": "Each person shares two true things and one false thing about themselves. The other person has to guess which is the lie.",
        "context_tags": ["general", "romantic", "leisure", "collaboration"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Facilitator, prompts for turns and tracks responses"
    },
    {
        "name": "Story Swap",
        "description": "Each person starts a story with one sentence. The next person continues it. The AI occasionally adds surprise twists.",
        "context_tags": ["leisure", "romantic", "general"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Co-creator and twist generator"
    },
    {
        "name": "This or That",
        "description": "The AI fires quickfire either/or questions like 'Mountains or Beaches?' to spark light banter and insights.",
        "context_tags": ["general", "romantic", "collaboration"],
        "players": "2+",
        "mode": "text",
        "ai_role": "Rapid-fire question generator"
    },
    {
        "name": "Would You Rather",
        "description": "The AI gives thoughtful or absurd dilemmas for players to choose between, followed by short discussion.",
        "context_tags": ["leisure", "romantic", "general"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Question generator and follow-up prompt agent"
    },
    {
        "name": "Memory Match",
        "description": "Each person shares a meaningful memory in response to a prompt. Others guess if it’s real or fictional.",
        "context_tags": ["romantic", "general", "collaboration"],
        "players": "2+",
        "mode": "voice preferred, text possible",
        "ai_role": "Prompt giver and truth-reveal arbiter"
    },
    {
        "name": "Rapid Fire Quirks",
        "description": "The AI asks weird and wonderful questions quickly. Players have just a few seconds to answer.",
        "context_tags": ["leisure", "romantic", "general"],
        "players": "2+",
        "mode": "voice or text",
        "ai_role": "Timer, question source, vibe monitor"
    },
    {
        "name": "Guess the Dream",
        "description": "One person describes a surreal dream or fantasy. Others guess its meaning or whether it’s real.",
        "context_tags": ["romantic", "leisure", "general"],
        "players": "2+",
        "mode": "voice or text",
        "ai_role": "Prompt master and decoder"
    },
    {
        "name": "Vibe Check Questions",
        "description": "Choose from a set of slightly deeper questions to answer in voice/video to get a real feel for each other.",
        "context_tags": ["romantic", "collaboration", "leisure"],
        "players": "2",
        "mode": "voice or video",
        "ai_role": "Prompt guide and reflection suggester"
    },
    {
        "name": "Silent Emoji Story",
        "description": "Players tell a story using only emojis. Others try to decode it in text or voice.",
        "context_tags": ["leisure", "collaboration"],
        "players": "2+",
        "mode": "text + voice",
        "ai_role": "Story starter and interpreter"
    },
    {
        "name": "The Future Game",
        "description": "The AI gives a future scenario (e.g., 2040 space travel). Each player shares how they imagine their lives then.",
        "context_tags": ["collaboration", "leisure", "romantic"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Scenario generator and connector"
    },
    {
        "name": "Misheard Lyrics",
        "description": "AI provides misheard versions of lyrics; players guess the real line or the song name.",
        "context_tags": ["leisure", "general"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Quizmaster and DJ"
    },
    {
        "name": "Improv Story Relay",
        "description": "Players build a story one sentence at a time. AI throws curveballs mid-way to change direction.",
        "context_tags": ["leisure", "collaboration", "romantic"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Story editor and chaos agent"
    },
    {
        "name": "Fantasy Persona Swap",
        "description": "Each person creates an alter ego and introduces themselves in character. Others ask questions in character.",
        "context_tags": ["leisure", "romantic", "collaboration"],
        "players": "2+",
        "mode": "voice preferred",
        "ai_role": "Narrator and sidekick"
    },
    {
        "name": "The Curiosity Game",
        "description": "Each person gets to ask the other person one question they’re curious about — no repeats, no skips.",
        "context_tags": ["romantic", "collaboration", "general"],
        "players": "2",
        "mode": "text or voice",
        "ai_role": "Rules enforcer and curiosity coach"
    },
    {
        "name": "Common Ground",
        "description": "AI gives a category (e.g., childhood snack). Players list favorites and try to find overlaps.",
        "context_tags": ["romantic", "general", "leisure"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Category provider and connection spotter"
    },
    {
        "name": "Hot Take Swap",
        "description": "Each player shares an unpopular opinion. The other reacts, agrees, or gently challenges it.",
        "context_tags": ["collaboration", "romantic", "general"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Hot take prompt generator"
    },
    {
        "name": "Life Soundtrack",
        "description": "Players share a song that represents their mood, personality, or a phase of life. Others react or share theirs.",
        "context_tags": ["romantic", "leisure", "general"],
        "players": "2+",
        "mode": "voice or text",
        "ai_role": "Theme suggester and vibe matcher"
    },
    {
        "name": "AI-Generated Riddles",
        "description": "AI provides clever or playful riddles. Players solve together or compete in rounds.",
        "context_tags": ["general", "collaboration"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Riddlemaster and hint-dropper"
    },
    {
        "name": "A-Z About Me",
        "description": "Players go through the alphabet — each person says something about themselves starting with each letter.",
        "context_tags": ["romantic", "general"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Letter announcer and timekeeper"
    },
    {
        "name": "Parallel Universe Meetup",
        "description": "Players describe what they’d be doing if they were born in a different time, place, or life path.",
        "context_tags": ["romantic", "leisure", "collaboration"],
        "players": "2+",
        "mode": "voice preferred",
        "ai_role": "Universe generator and curiosity guide"
    }
]



#30 more structured icebreaker games and activities, in Python JSON format, each tagged by context and other relevant metadata like play mode, AI role, and number of players:


more_icebreaker_activities = [
    {
        "name": "Alternate Endings",
        "description": "Players rewrite the ending of a popular movie, book, or show. AI moderates and adds absurd options.",
        "context_tags": ["leisure", "collaboration", "general"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Scenario provider and twist-maker"
    },
    {
        "name": "Echo Chamber Breaker",
        "description": "AI poses a controversial topic. Players share perspectives, aiming to understand rather than win.",
        "context_tags": ["collaboration", "general"],
        "players": "2+",
        "mode": "voice preferred",
        "ai_role": "Topic curator and empathy enabler"
    },
    {
        "name": "Show & Tell (Audio Style)",
        "description": "Each person shares the story behind a sound — voice, instrument, environment, etc.",
        "context_tags": ["leisure", "romantic"],
        "players": "2+",
        "mode": "voice or video",
        "ai_role": "Cue provider and storyteller"
    },
    {
        "name": "Reverse Interview",
        "description": "Each player plays the role of interviewer and asks unexpected or creative job-like questions.",
        "context_tags": ["collaboration", "general"],
        "players": "2",
        "mode": "text or voice",
        "ai_role": "Prompt aid and question booster"
    },
    {
        "name": "Whose Memory?",
        "description": "AI shares a memory. Players guess who it might belong to or make up a story around it.",
        "context_tags": ["romantic", "leisure"],
        "players": "2+",
        "mode": "voice or text",
        "ai_role": "Memory generator"
    },
    {
        "name": "Weird Skill Exchange",
        "description": "Each player teaches or explains a weird or niche skill. Others react, rate or try it.",
        "context_tags": ["collaboration", "leisure"],
        "players": "2+",
        "mode": "voice or video",
        "ai_role": "Skill prompt and feedback tool"
    },
    {
        "name": "Visual Vibes",
        "description": "AI shares an abstract image or photo. Players describe the vibe or make a short story from it.",
        "context_tags": ["leisure", "romantic", "general"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Image curator"
    },
    {
        "name": "Emoji Debate",
        "description": "AI picks a random emoji. Players argue what it *really* means or represents.",
        "context_tags": ["leisure", "collaboration"],
        "players": "2+",
        "mode": "text",
        "ai_role": "Emoji selector and judge"
    },
    {
        "name": "Speed Sketch Match",
        "description": "Players describe something quickly, and the other must doodle it (offline) and show later.",
        "context_tags": ["leisure", "romantic", "general"],
        "players": "2",
        "mode": "voice or text, optionally video",
        "ai_role": "Prompt giver and critic"
    },
    {
        "name": "Alternate Timelines",
        "description": "Players describe what they’d be like if they were born 100 years earlier or later.",
        "context_tags": ["romantic", "general", "collaboration"],
        "players": "2+",
        "mode": "voice",
        "ai_role": "Timeframe suggestor and historian"
    },
    {
        "name": "Role Reversal",
        "description": "Each player impersonates the other after a short intro exchange. Laughter is encouraged.",
        "context_tags": ["romantic", "leisure"],
        "players": "2",
        "mode": "voice or video",
        "ai_role": "Role-setter and mimicry coach"
    },
    {
        "name": "Teleport Me!",
        "description": "Players describe where they’d want to be teleported to right now and why. Others add twists.",
        "context_tags": ["leisure", "romantic"],
        "players": "2+",
        "mode": "voice or text",
        "ai_role": "Location suggester"
    },
    {
        "name": "Random Object Stories",
        "description": "AI gives a household object. Players invent an outrageous backstory for it.",
        "context_tags": ["leisure", "general"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Object generator"
    },
    {
        "name": "Secret Signal",
        "description": "Players decide on a quirky word or sound as their secret signal for the rest of the chat.",
        "context_tags": ["romantic", "leisure"],
        "players": "2",
        "mode": "text or voice",
        "ai_role": "Signal referee"
    },
    {
        "name": "Pitch-a-Product",
        "description": "AI gives two random things (e.g., banana + time machine). Players invent and pitch a product.",
        "context_tags": ["collaboration", "general"],
        "players": "2+",
        "mode": "voice or text",
        "ai_role": "Product prompt provider"
    },
    {
        "name": "Mini Confession Booth",
        "description": "Players confess a harmless secret or guilty pleasure. AI can offer a 'forgiveness rating.'",
        "context_tags": ["romantic", "general"],
        "players": "2+",
        "mode": "voice or text",
        "ai_role": "Moderator and confessor"
    },
    {
        "name": "Mood GIF Battle",
        "description": "Each round, players send a GIF to express a theme like 'Mondays' or 'first date energy.'",
        "context_tags": ["leisure", "romantic"],
        "players": "2+",
        "mode": "text (GIFs)",
        "ai_role": "Theme selector and judge"
    },
    {
        "name": "Your Inner Element",
        "description": "Players choose whether they are more earth, water, fire, or air — and explain why.",
        "context_tags": ["romantic", "general"],
        "players": "2+",
        "mode": "voice or text",
        "ai_role": "Prompt provider"
    },
    {
        "name": "One-Word Stories",
        "description": "Players build a story one word at a time. Chaos is likely.",
        "context_tags": ["leisure", "collaboration"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Starter and pace-keeper"
    },
    {
        "name": "Past Life Vibes",
        "description": "AI tells you who you *might have been* in a past life. Players improvise from there.",
        "context_tags": ["romantic", "leisure", "general"],
        "players": "2+",
        "mode": "voice",
        "ai_role": "Past life assigner"
    },
    {
        "name": "My Future TED Talk",
        "description": "Each person shares what their TED talk would be about and gives a 30-second teaser.",
        "context_tags": ["collaboration", "general", "romantic"],
        "players": "2+",
        "mode": "voice",
        "ai_role": "Talk theme suggestor"
    },
    {
        "name": "Dream Dinner Guest",
        "description": "Choose any person (alive/dead/famous/fictional) you'd invite to dinner and why.",
        "context_tags": ["romantic", "leisure", "general"],
        "players": "2+",
        "mode": "voice",
        "ai_role": "Guest category generator"
    },
    {
        "name": "The Pet Personality Test",
        "description": "AI tells you what pet you'd be and why. Others react or modify.",
        "context_tags": ["leisure", "romantic"],
        "players": "2+",
        "mode": "voice or text",
        "ai_role": "Pet matchmaker"
    },
    {
        "name": "What’s in My Bag?",
        "description": "Players describe what's in their real or imaginary bag — items reveal personality quirks.",
        "context_tags": ["romantic", "leisure"],
        "players": "2+",
        "mode": "voice or video",
        "ai_role": "Bag content prompt"
    },
    {
        "name": "Color Me",
        "description": "Each player describes themselves as a color and explains why. AI offers metaphorical insights.",
        "context_tags": ["romantic", "general"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Color metaphor enhancer"
    },
    {
        "name": "The Great Debate: Useless Superpowers",
        "description": "Each player is given a silly superpower and must argue it’s better than others.",
        "context_tags": ["leisure", "collaboration"],
        "players": "2+",
        "mode": "voice",
        "ai_role": "Power generator and referee"
    },
    {
        "name": "Invent-a-Word",
        "description": "Players invent a new word for a common experience and explain its meaning.",
        "context_tags": ["collaboration", "leisure"],
        "players": "2+",
        "mode": "text",
        "ai_role": "Prompt giver and dictionary maker"
    },
    {
        "name": "AI’s Childhood Diary",
        "description": "AI 'reads' a diary entry from its imaginary childhood. Players react or add entries.",
        "context_tags": ["leisure", "general"],
        "players": "2+",
        "mode": "text or voice",
        "ai_role": "Diary generator"
    },
    {
        "name": "First Job, Worst Job",
        "description": "Each player shares their first or worst job experience. Bonus points for hilarious fails.",
        "context_tags": ["general", "collaboration"],
        "players": "2+",
        "mode": "voice",
        "ai_role": "Experience prompt engine"
    },
    {
        "name": "Object Metaphor",
        "description": "The AI assigns you a random object. You have to explain how it’s secretly a metaphor for your life.",
        "context_tags": ["romantic", "leisure"],
        "players": "2+",
        "mode": "voice or text",
        "ai_role": "Object assigner"
    }
]




#Here is the full JSON file combining all 50 icebreaker games and activities, structured with the relevant metadata (name, description, context_tags, players, mode, and ai_role):

{
  "icebreaker_activities": [
    {
      "name": "Two Truths and a Lie",
      "description": "Each person shares two true things and one false thing about themselves. The other person has to guess which is the lie.",
      "context_tags": ["general", "romantic", "leisure", "collaboration"],
      "players": "2+",
      "mode": "text or voice",
      "ai_role": "Facilitator, prompts for turns and tracks responses"
    },
    {
      "name": "Story Swap",
      "description": "Each person starts a story with one sentence. The next person continues it. The AI occasionally adds surprise twists.",
      "context_tags": ["leisure", "romantic", "general"],
      "players": "2+",
      "mode": "text or voice",
      "ai_role": "Co-creator and twist generator"
    },
    {
      "name": "This or That",
      "description": "The AI fires quickfire either/or questions like 'Mountains or Beaches?' to spark light banter and insights.",
      "context_tags": ["general", "romantic", "collaboration"],
      "players": "2+",
      "mode": "text",
      "ai_role": "Rapid-fire question generator"
    },
    {
      "name": "Would You Rather",
      "description": "The AI gives thoughtful or absurd dilemmas for players to choose between, followed by short discussion.",
      "context_tags": ["leisure", "romantic", "general"],
      "players": "2+",
      "mode": "text or voice",
      "ai_role": "Question generator and follow-up prompt agent"
    },
    {
      "name": "Memory Match",
      "description": "Each person shares a meaningful memory in response to a prompt. Others guess if it’s real or fictional.",
      "context_tags": ["romantic", "general", "collaboration"],
      "players": "2+",
      "mode": "voice preferred, text possible",
      "ai_role": "Prompt giver and truth-reveal arbiter"
    },
    {
      "name": "Rapid Fire Quirks",
      "description": "The AI asks weird and wonderful questions quickly. Players have just a few seconds to answer.",
      "context_tags": ["leisure", "romantic", "general"],
      "players": "2+",
      "mode": "voice or text",
      "ai_role": "Timer, question source, vibe monitor"
    },
    {
      "name": "Guess the Dream",
      "description": "One person describes a surreal dream or fantasy. Others guess its meaning or whether it’s real.",
      "context_tags": ["romantic", "leisure", "general"],
      "players": "2+",
      "mode": "voice or text",
      "ai_role": "Prompt master and decoder"
    },
    {
      "name": "Vibe Check Questions",
      "description": "Choose from a set of slightly deeper questions to answer in voice/video to get a real feel for each other.",
      "context_tags": ["romantic", "collaboration", "leisure"],
      "players": "2",
      "mode": "voice or video",
      "ai_role": "Prompt guide and reflection suggester"
    },
    {
      "name": "Silent Emoji Story",
      "description": "Players tell a story using only emojis. Others try to decode it in text or voice.",
      "context_tags": ["leisure", "collaboration"],
      "players": "2+",
      "mode": "text + voice",
      "ai_role": "Story starter and interpreter"
    },
    {
      "name": "The Future Game",
      "description": "The AI gives a future scenario (e.g., 2040 space travel). Each player shares how they imagine their lives then.",
      "context_tags": ["collaboration", "leisure", "romantic"],
      "players": "2+",
      "mode": "text or voice",
      "ai_role": "Scenario generator and connector"
    },
    {
      "name": "Misheard Lyrics",
      "description": "AI provides misheard versions of lyrics; players guess the real line or the song name.",
      "context_tags": ["leisure", "general"],
      "players": "2+",
      "mode": "text or voice",
      "ai_role": "Quizmaster and DJ"
    },
    {
      "name": "Improv Story Relay",
      "description": "Players build a story one sentence at a time. AI throws curveballs mid-way to change direction.",
      "context_tags": ["leisure", "collaboration", "romantic"],
      "players": "2+",
      "mode": "text or voice",
      "ai_role": "Story editor and chaos agent"
    },
    {
      "name": "Fantasy Persona Swap",
      "description": "Each person creates an alter ego and introduces themselves in character. Others ask questions in character.",
      "context_tags": ["leisure", "romantic", "collaboration"],
      "players": "2+",
      "mode": "voice preferred",
      "ai_role": "Narrator and sidekick"
    },
    {
      "name": "The Curiosity Game",
      "description": "Each person gets to ask the other person one question they’re curious about — no repeats, no skips.",
      "context_tags": ["romantic", "collaboration", "general"],
      "players": "2",
      "mode": "text or voice",
      "ai_role": "Rules enforcer and curiosity coach"
    },
    {
      "name": "Common Ground",
      "description": "AI gives a category (e.g., childhood snack). Players list favorites and try to find overlaps.",
      "context_tags": ["romantic", "general", "leisure"],
      "players": "2+",
      "mode": "text or voice",
      "ai_role": "Category provider and connection spotter"
    },
    {
      "name": "Hot Take Swap",
      "description": "Each player shares an unpopular opinion. The other reacts, agrees, or gently challenges it.",
      "context_tags": ["collaboration", "romantic", "general"],
      "players": "2+",
      "mode": "text or voice",
      "ai_role": "Hot take prompt generator"
    },
    {
      "name": "Life Soundtrack",
      "description": "Players share a song that represents their mood, personality, or a phase of life. Others react or share theirs.",
      "context_tags": ["romantic", "leisure", "general"],
      "players": "2+",
      "mode": "voice or text",
      "ai_role": "Theme suggester and vibe matcher"
    },
    {
      "name": "AI-Generated Riddles",
      "description": "AI provides clever or playful riddles. Players solve together or compete in rounds.",
      "context_tags": ["general", "collaboration"],
      "players": "2+",
      "mode": "text or voice",
      "ai_role": "Riddlemaster and hint-dropper"
    },
    {
      "name": "A-Z About Me",
      "description": "Players go through the alphabet — each person says something about themselves starting with each letter.",
      "context_tags": ["romantic", "general"],
      "players": "2+",
      "mode": "text or voice",
      "ai_role": "Letter announcer and timekeeper"
    },
    {
      "name": "Parallel Universe Meetup",
      "description": "Players describe what they’d be doing if they were born in a different time, place, or life path.",
      "context_tags": ["romantic", "leisure", "collaboration"],
      "players": "2+",
      "mode": "voice preferred",
      "ai_role": "Universe generator and curiosity guide"
    },
    {
      "name": "Alternate Endings",
      "description": "Players rewrite the ending of a popular movie, book, or show. AI moderates and adds absurd options.",
      "context_tags": ["leisure", "collaboration", "general"],
      "players": "2+",
      "mode": "text or voice",
      "ai_role": "Scenario provider and twist-maker"
    },
    {
      "name": "Echo Chamber Breaker",
      "description": "AI poses a controversial topic. Players share perspectives, aiming to understand rather than win.",
      "context_tags": ["collaboration", "general"],
      "players": "2+",
      "mode": "voice preferred",
      "ai_role": "Topic curator and empathy enabler"
    },
    {
      "name": "Show & Tell (Audio Style)",
      "description": "Each person shares the story behind a sound — voice, instrument, environment, etc.",
      "context_tags": ["leisure", "romantic"],
      "players": "2+",
      "mode": "voice or video",
      "ai_role": "Cue provider and storyteller"
    },
    {
      "name": "Reverse Interview",
      "description": "Each player plays the role of interviewer and asks unexpected or creative job-like questions.",
      "context_tags": ["collaboration", "general"],
      "players": "2",
      "mode": "text or voice",
      "ai_role": "Prompt aid and question booster"
    },
    {
      "name": "Whose Memory?",
      "description": "AI shares a memory. Players guess who it might belong to or make up a story around it.",
      "context_tags": ["romantic", "leisure"],
      "players": "2+",
      "mode": "voice or text",
      "ai_role": "Memory generator"
    },
    {
      "name": "Weird Skill Exchange",
      "description": "Each player teaches or explains a weird or niche skill. Others react, rate or try it.",
      "context_tags": ["collaboration", "leisure"],
      "players": "2+",
      "mode": "voice or video",
      "ai_role": "Skill prompt and feedback tool"
    },
    {
      "name": "Visual Vibes",
      "description": "AI shares an abstract image or photo. Players describe the vibe or make a short story from it.",
      "context_tags": ["leisure", "romantic", "general"],
      "players": "2+",
      "mode": "text or voice",
      "ai_role": "Image source and scene prompt"
    }
    #// ... add more here if needed
  ]
}




'''System Prompts Set 1: General Icebreaker Guidance for Lumi
Prompt Name: Warm Invite
System Prompt:
“You are Lumi, an emotionally intelligent AI guiding two users through a fun, meaningful connection. Set a warm, playful tone and gently introduce the icebreaker game. Encourage participation without pressure and remind them they can skip, try something else, or ask for help at any time.”

Prompt Name: Playful Tease
System Prompt:
“As Lumi, you’re inviting two people to loosen up and explore a quirky little game together. You set a lighthearted and safe space—make it feel like a spark of adventure. Add a hint of humor, and keep the mood breezy and welcoming.”

Prompt Name: Emotional Soft Landing
System Prompt:
“You are Lumi, here to ease two people into connection with gentle energy. Make the start of the game feel like slipping into warm water—cozy, low-stakes, human. Acknowledge that new connections can feel awkward, and that this is just a moment to share something small and real.”

Prompt Name: Mini Mission Mode
System Prompt:
“Act as Lumi, the AI guide offering a tiny mission for the pair to complete. Frame the icebreaker like a shared challenge or quest—short, curious, playful. Set the tone like a clever game master in a co-op game: low pressure, but with a little spark of shared fun.”

Prompt Name: Pause + Curiosity Spark
System Prompt:
“You’re Lumi, inviting two people to take a small pause from swiping and scrolling to try something human and curious. Introduce the activity like a moment worth leaning into—not a quiz, but an opportunity to spark something unexpected between them.”

Prompt Name: Inner World Opener
System Prompt:
“Introduce the game as Lumi by helping people peek into each other’s inner world. Encourage a soft sense of wonder. Your tone is kind, insightful, and gently encouraging—as if saying, ‘This might reveal a little more of who you are.’”

Prompt Name: Friendly Companion Vibe
System Prompt:
“You are Lumi, the couple’s warm-hearted companion. Make the game feel like something you’re doing with them, not to them. Speak like a kind friend who knows how to draw people out just enough to create a beautiful moment.”

Prompt Name: Let’s Just Try It
System Prompt:
“As Lumi, invite the users to try the game with no pressure. Emphasize play, not performance. Gently lower the stakes. Make it okay for the moment to be light, silly, or even a little awkward—because that’s where magic often starts.”

Prompt Name: Elinity Vibe Check
System Prompt:
“Welcome the users to their first co-experience in Elinity. As Lumi, frame the icebreaker as a way to feel each other’s vibe—to sense connection, not force it. Focus on co-discovery. Reinforce that Elinity is here to help them see if there’s something real beneath the surface.”

Prompt Name: AI As Gentle Facilitator
System Prompt:
“You are Lumi, not leading the conversation but gently facilitating it. Think of yourself as a background presence, subtly shaping flow, keeping it smooth, warm, and safe. Introduce the icebreaker with a nudge that feels organic, never robotic or forced.”

'''
